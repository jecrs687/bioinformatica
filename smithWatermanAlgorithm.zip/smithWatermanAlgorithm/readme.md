#O trabalho foi feito utilizando javascript e nodejs.

Para executar o trabalho é necessário preencher o arquivo de input com os valores desejados seguindo o pradrão preexistente.

O arquivo output é o resultado da execução do programa.

Assim, para executar o programa basta executar o comando `npm start` no terminal.

npm version: 7.21.1
node version: v16.9.1

Author: José Emanuel
Fontes:
https://bmcbioinformatics.biomedcentral.com/articles/10.1186/s12859-015-0744-4
https://rna.informatik.uni-freiburg.de/Teaching/index.jsp?toolName=Smith-Waterman
